# Create calculator using Tkinter...

# Import Tkinter module.
from tkinter import *
import math

from virtualenv.discovery.cached_py_info import clear

# GUI interaction...
windows=Tk()
windows.geometry('300x400')
windows.config(bg="Blue")

# Adding input..
# Entry Box:

ent_box=Entry(windows, width=46,border=10)
ent_box.place(x=0,y=0)

# Button...

def click(num):
    result=ent_box.get()
    ent_box.delete(0,END)
    ent_box.insert(0,str(result)+str(num))

b =Button(windows,text='1',width=12,command=lambda:click(1))
b.place(x=7.5,y=60)
b =Button(windows,text='2',width=12,command=lambda:click(2))
b.place(x=103.5,y=60)
b =Button(windows,text='3',width=12,command=lambda:click(3))
b.place(x=198.5,y=60)

b =Button(windows,text='4',width=12,command=lambda:click(4))
b.place(x=7.5,y=120)
b =Button(windows,text='5',width=12,command=lambda:click(5))
b.place(x=103.5,y=120)
b =Button(windows,text='6',width=12,command=lambda:click(6))
b.place(x=198.5,y=120)

b =Button(windows,text='7',width=12,command=lambda:click(7))
b.place(x=7.5,y=180)
b =Button(windows,text='8',width=12,command=lambda:click(8))
b.place(x=103.5,y=180)
b =Button(windows,text='9',width=12,command=lambda:click(9))
b.place(x=198.5,y=180)

b =Button(windows,text='0',width=12,command=lambda:click(0))
b.place(x=7.5,y=240)

#  Operator.........

def add():
    n1=ent_box.get()
    global math
    math="Addition"
    global i
    i=int(n1)
    ent_box.delete(0,END)

b =Button(windows,text='+',width=12,command=add)
b.place(x=103.5,y=240)

def sub():
    n1=ent_box.get()
    global math
    math="Substraction"
    global i
    i = int(n1)
    ent_box.delete(0,END)

b =Button(windows,text='-',width=12,command=sub)
b.place(x=198.5,y=240)

def mul():
    n1=ent_box.get()
    global math
    math="Multiplication"
    global i
    i = int(n1)
    ent_box.delete(0,END)

b =Button(windows,text='*',width=12,command=mul)
b.place(x=7.5,y=300)

def mod():
    n1=ent_box.get()
    global math
    math="Mod"
    global i
    i = int(n1)
    ent_box.delete(0,END)

b =Button(windows,text='%',width=12,command=mod)
b.place(x=103.5,y=300)

def div():
    n1=ent_box.get()
    global math
    math="Division"
    global i
    i = int(n1)
    ent_box.delete(0,END)

b =Button(windows,text='/',width=12,command=div)
b.place(x=198.5,y=300)

def equal():
    n2=ent_box.get()
    ent_box.delete(0,END)

    if math=="Addition":
        ent_box.insert(0,i+int(n2))
    elif math=="Substraction":
        ent_box.insert(0, i - int(n2))
    elif math=="Multiplication":
        ent_box.insert(0, i * int(n2))
    elif math=="Division":
        ent_box.insert(0, i / int(n2))
    elif math=="Mod":
        ent_box.insert(0, i % int(n2))

b =Button(windows,text='=',width=12,command=equal)
b.place(x=7.5,y=360)

b =Button(windows,text='Enter',width=12,command=equal)
b.place(x=103.5,y=360)

def clear():
    ent_box.delete(0,END)
b =Button(windows,text='Clear',width=12,command=clear)
b.place(x=198.5,y=360)
# Mainloop..
windows.mainloop()