# Tkinter is slandered library which is used for create desktop application and Graphical user interface(GUI).
# Steps:
# # 1- Import Tkinter module.
# from tkinter import *
#
# # 2- GUI interaction using TK() of TK class
# wim = Tk()
#
# # 3- Adding input using Label().
# inp=Label(wim,text="Hello World")
# inp.pack()                          # pack() method is used to organised widgets in the block.
#
# # 4- main Loop.
# wim.mainloop()
from idlelib.debugger_r import frametable
from locale import windows_locale
from optparse import check_builtin
#--------------------------------------------------------------------------------------------

# 2.Basic information using Tkinter.
# from tkinter import *
# windows=Tk()
#
# # provide th tile using title().
# windows.title("Simple")
#
# # Change height and width using geometry().
# windows.geometry('500x500')
#
# # Change background color using 'bg' attribute of config().
# windows.config(bg="Yellow")
#
# # call mainloop()
# windows.mainloop()

#--------------------------------------------------------------------------------------------

# How to create Frame and Button using Tkinter.

# from tkinter import *
# # GUI interaction
# a=Tk()

# #Adding Input..
# a.title("Simple")
# a.geometry("500x600")
# a.config(bg="Yellow")
# # frame1=Frame(a,bg="red",width=200,height=200,cursor="dot")
# # frame1.pack(side='top')
# # frame2=Frame(a,bg="Green",width=200,height=200,cursor="dotbox")
# # frame2.pack(side="bottom")

# # Create Button...
# frame1=Frame(a,width=200,height=200,cursor="dot")
# frame1.pack(side='top')
# frame2=Frame(a,width=200,height=200,cursor="dotbox")
# frame2.pack(side="bottom")
#
# Button1=Button(frame1,text="Button_01",bg="blue")               # bg => Background color
# Button1.pack(side="top")
# Button2=Button(frame2,text="Button_02",bg="blue")
# Button2.pack(side="bottom")
# Button3=Button(frame1,text="Login",fg="red")                  # Fg => Foreground color.
# Button3.pack(side="top")
# a.mainloop()

#--------------------------------------------------------------------------------------------------

# Entry point and grid layout using tkinter.

# #import module..............
# from tkinter import *
# # GUI interaction............
# wind = Tk()
# #Adding input............
# wind.title("Simple")
# wind.geometry("500x500")
# wind.config(bg="YELLOW")
# label1=Label(wind,text="Email_Id :",fg='Green')
# label1.grid(row=0,column=1)
# # label1.pack()
# e1 = Entry(wind,width=40,borderwidth=5)
# e1.grid(row=0,column=2)
#
# label2=Label(wind,text="Password :",fg='Green')
# label2.grid(row=1,column=1)
# # label2.pack()
# e2=Entry(wind,width=40,borderwidth=5)
# e2.grid(row=1,column=2)
#
# button=Button(wind,text="Login",bg="Grey",fg="White")
# button.grid(row=2,column=1)
# button1=Button(wind,text="Reset",bg="Grey",fg="White")
# button1.grid(row=2,column=2)
# wind.mainloop()

#--------------------------------------------------------------------------------------------------------

# pack() is used for organise the input in block.

# from tkinter import *
# windows=Tk()
# windows.title("Simple")
# windows.geometry('500x500')
# windows.config(bg='yellow')

# label1=Label(windows,text="Label-01",bg="Green",fg="White")
# label2=Label(windows,text="Label-02",bg="Red",fg="White")
# label3=Label(windows,text="Label-03",bg="Blue",fg="White")
# label4=Label(windows,text="Label-04",bg="Grey",fg="White")

# label1.pack(side=TOP, fill=X,expand=FALSE)           # by default => side=TOP,fill=X,expand=FALSE
# label2.pack(side=LEFT, fill=Y,expand=FALSE)
# label3.pack(side=RIGHT, fill=Y,expand=FALSE)
# label4.pack(side=BOTTOM, fill=X,expand=FALSE)

# windows.mainloop()

#-----------------------------------------------------------------------------------------------

# Handling Button:

# from tkinter import *
# windows=Tk()
# windows.title("Simple")
# windows.geometry("200x200")
# windows.config(bg="yellow")
#
# def log_entry():
#     print("User Logged...")
# button=Button(windows,text="Login",bg="red",fg="White",command=log_entry,font=("bold",12),width=12,activebackground="Grey",activeforeground="Blue")
# #button.pack(side=TOP,expand=FALSE)
# button.pack(side=TOP,expand=TRUE)
# windows.mainloop()

#----------------------------------------------------------------------------------------------------
#
# # MenuBar : using Menu class.
# from tkinter import *
# windows=Tk()
# windows.title("Simple")
# windows.geometry("500x500")
# #Adding input..
#
# menu=Menu(windows)
# # create Parent menu bar
# file=Menu(menu,tearoff=0)                       # tear-off=1 is default value, and it is used to floating menu bar over here.
# # create Child menu
# file.add_command(label="New")
# file.add_command(label="Open")
# file.add_command(label="Save")
# file.add_command(label="Save as")
# #separete line
# file.add_separator()
# file.add_command(label="Exit",command=windows.quit)
# #file.add_command(label="Exit",command=file.quit)
# #file.add_command(label="Exit",command=menu.quit)
# menu.add_cascade(label="File",menu=file)
# windows.config(bg="yellow",menu=menu)
#
# windows.mainloop()

#-----------------------------------------------------------------------------------------------------

# Message Box :

# from tkinter import *
# import tkinter.messagebox
#
# windows=Tk()
#
# windows.title("Simple")
# windows.geometry("200x200")
# windows.config(bg="grey")
#
# #tkinter.messagebox.showinfo("Info","Running out of time")
# tkinter.messagebox.showwarning("Warning","Will it rain?")
# #tkinter.messagebox.showerror("Error","Found some error in its.")
#
# question=tkinter.messagebox.askyesno("Message","Will it rain.")
#
# if question==TRUE:
#     print("Kindly take an umbrella..")
# else:
#     print("Go without umbrella..")
# windows.mainloop()

#---------------------

# MessageBox-2:

from tkinter import *
from tkinter import messagebox

windows=Tk()
windows.title("Sample")
windows.geometry('500x500')
windows.config(bg='yellow')

# mesage=Message(windows,text="Hello Ji !..",padx=20,pady=20)
# mesage.pack()

# var=StringVar()
# mesage=Message(windows,textvariable=var,relief=RAISED,border=5,padx=20,pady=20)
# var.set("Welcome")
# mesage.pack()

var = StringVar()
ent_var=StringVar()

def insert():
    result=ent_var.get()
    var.set(result)

mesage=Message(windows,textvariable=var,relief=RAISED,padx=50,pady=50)

entry=Entry(windows,textvariable=ent_var)

button=Button(windows,text="Ok",command=insert)

mesage.pack()
entry.pack()
button.pack()

windows.mainloop()



#--------------------------------------------------------------------------------------------------------
# Drawing....using canvas() class
# from tkinter import *
# #GUI interaction
# windows=Tk()
# #Adding input..
# canvs=Canvas(windows,width=500,height=500,bg="pink",border=12)
# canvs.pack()
#
# canvs.create_line(0,0,500,500,fill='green',width=2)
# canvs.create_line(500,0,0,500,fill="red",width=2)
# #canvs.create_rectangle(0,250,250,0,fill="blue",width=5)
# # center rectangle..
# rect_width=100
# rect_height=100
#
# canvs.create_rectangle(400,600,400,600,fill="yellow",width=5)
#
# windows.mainloop()

#-------------------------------------------------------------------------------------------------
# checkbutton :

# from tkinter import *
#
# windows=Tk()
# windows.geometry('500x500')
# # c1=IntVar()
# # c2=IntVar()
# # c3=IntVar()
# cb1=Checkbutton(windows,text="HDD",width=10,height=2,onvalue=1,offvalue=0)
# cb2=Checkbutton(windows,text="SSD",width=10,height=2,onvalue=1,offvalue=0)
# cb3=Checkbutton(windows,text="NVME",width=10,height=2,onvalue=1,offvalue=0)
#
# cb1.pack()
# cb2.pack()
# cb3.pack()

# windows.mainloop()

#-------------------------------------------------------------------------
#place: using the place() class.

# from tkinter import *
# windows=Tk()
# windows.geometry('300x300')
# windows.config(bg="pink")
#
# button=Button(windows,text="Login",borderwidth=5,width=10,bg="grey",fg="White",activeforeground="red",activebackground="yellow")
# button.place(x=100,y=130)
# windows.mainloop()